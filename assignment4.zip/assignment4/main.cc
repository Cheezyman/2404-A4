#include <iostream>
#include <fstream>
#include <string>
#include "Controller.h"
#include "View.h"
#include <vector>

using namespace std;

int main()
{
    Controller control;
    control.launch();
    return 0;
}